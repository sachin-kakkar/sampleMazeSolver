package com.sample.service;

import com.sample.exception.MazeBusinessException;
import org.junit.Assert;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;


public class MazeServiceTest {

    @Test
    public void checkInvalidInputParameters()  {

        try {
            MazeServiceImpl.main(null);
        } catch (MazeBusinessException ex) {
            Assert.assertEquals("usage: file\n -file <arg>   input file name", ex.getMessage());
        }


        try {
            MazeServiceImpl.main(new String[]{"file"});
        } catch (MazeBusinessException ex) {
            Assert.assertEquals("File name cannot be blank. Please provide filename with absolute path", ex.getMessage());
        }

        try {
            MazeServiceImpl.main(new String[]{"-file"});
        } catch (MazeBusinessException ex) {
            Assert.assertEquals(ex.getMessage(), "Cannot proceed as input parameters not read. Please contact support/dev team@someaddress");
        }
    }

    @Test(expected = MazeBusinessException.class)
    public void checkMissingFileName() {
        MazeService MazeService = new MazeServiceImpl();

        MazeService.markPath("");
    }

    @Test(expected = MazeBusinessException.class)
    public void checkInvalidFilePath() {
        MazeService MazeService = new MazeServiceImpl();

        // File in wrong format i.e. anything other than .txt file
        MazeService.markPath("Junk File");
    }

    @Test(expected = MazeBusinessException.class)
    public void checkFileMimeType()  throws IOException{
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("Test.pdf").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test(expected = MazeBusinessException.class)
    public void checkEmptyFile()  throws IOException{
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("EmptyFile.txt").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test(expected = MazeBusinessException.class)
    public void fileContainsTwoStartingPoints() {
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("TwoStartingPoints.txt").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test(expected = MazeBusinessException.class)
    public void fileContainsTwoEndPoints() {
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("TwoEndPoints.txt").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test(expected = MazeBusinessException.class)
    public void fileMissingStartingPoint() {
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("MissingStartingPoint.txt").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test(expected = MazeBusinessException.class)
    public void fileMissingEndPoint() {
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("MissingEndPoint.txt").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test(expected = MazeBusinessException.class)
    public void fileContainInvalidChar() {
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("InvalidMaze.txt").getFile());
        MazeService.markPath(file.getAbsolutePath());
    }

    @Test
    public void validInput()  throws IOException{
        final char[][] expectedOutput = new char[][] {
                {'#','#','#','#','#','#','#'},
                {'#','.','.','.',' ',' ','#'},
                {'#','.','#','.','#',' ','#'},
                {'#','.','#','E','#',' ','#'},
                {'#','.','#','#','#',' ','#'},
                {'#','S','#',' ','#',' ','#'},
                {'#',' ','#','#','#','#','#'}
        };

        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("Maze.txt").getFile());
        final char[][] actualOutput = MazeService.markPath(file.getAbsolutePath());
        System.out.print(Arrays.deepToString(actualOutput));

        assertTrue(Arrays.deepEquals(actualOutput, expectedOutput));
    }

    @Test
    public void NoPath()  throws IOException{
        MazeService MazeService = new MazeServiceImpl();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("NoPathMaze.txt").getFile());
        try {
            MazeService.markPath(file.getAbsolutePath());
        } catch (MazeBusinessException ex) {
            Assert.assertEquals("No path found in Maze.", "No path found in Maze.");
        }
    }

}
