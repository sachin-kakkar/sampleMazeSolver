package com.sample.service;

/**
 * This Service helps to find continuous path from
 * point marked 'S' to point marked 'E' in a two dimensional grid.
 * Path is marked using '.' signs
 *
 * Example :
 *  #########
 *  ##S     #
 *  ##### ###
 *  #####E###
 *
 *  Will me changed to
 *  #########
 *  ##S...  #
 *  #####.###
 *  #####E###
 *
 */
public interface MazeService {

    // Provides interface to request path from S to E point in a service.
    // Generates Maze (char[][] )from an input file.
    public char[][] markPath(String fileName);
}
