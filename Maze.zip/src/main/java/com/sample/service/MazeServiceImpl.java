package com.sample.service;

import com.sample.exception.MazeBusinessException;
import com.sample.validator.ValidateFactory;
import com.sample.validator.content.ContentValidator;
import com.sample.validator.file.FileValidator;
import org.apache.commons.cli.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

public class MazeServiceImpl implements MazeService {

    public static void main(String[] args) {

        CommandLine cmd = parseInputParameters(args);
        if (cmd.getOptionValue("file") != null) {

            MazeService mazeService = new MazeServiceImpl();
            char[][] actualOutput = mazeService.markPath(cmd.getOptionValue("file"));
            System.out.print(Arrays.deepToString(actualOutput));

        }
    }


    private char[][] markPath(char[][] input) {
        // List of validations to be performed can be added to factory. This ensure
        // required validations are done before processing begins. Cost to catch data issue
        // earlier is cheaper than mid way during processing. If validation fails it is expected
        // to throw a runtime exception and terminate execution.
        for (ContentValidator validator : ValidateFactory.getContentValidators()) {
            validator.check(input);
        }

        int startAtRow = -1;
        int startAtColumn = -1;

        // Find location of Starting point.
        for (int row = 0; row < input.length ; row++) {
            for (int col = 0; col < input[row].length; col++) {
                char data = input[row][col];
                if (data == 'S') {
                    startAtRow = row;
                    startAtColumn = col;
                    break;
                }
            }
            if (startAtRow != -1 && startAtColumn != -1) {
                break;
            }
        }

        boolean mazeSolved = identifyPath(input, startAtRow, startAtColumn);
        if (!mazeSolved) {throw new MazeBusinessException("No path found in Maze.");}
        return input;
    }

    public final char[][] markPath(String fileName) {
        // List of validations to be performed can be added to factory. This ensure
        // required validations are done before processing begins. Cost to catch data issue
        // earlier is cheaper than mid way during processing. If validation fails it is expected
        // to throw a runtime exception and terminate execution.
        for (FileValidator validator : ValidateFactory.getFileValidators()) {
            validator.check(fileName);
        }

        char[][] inputArray = parseFileToCharArray(fileName);
        char[][] solvedMaze = markPath(inputArray);
        return twoDimensionalArrayClone(solvedMaze);
    }

    private char[][] twoDimensionalArrayClone(char[][] source) {
        char[][] cloned = new char[source.length][];
        for (int i = 0; i < source.length; i++) {
            cloned[i] = source[i].clone();
        }
        return cloned;
    }

    private final boolean identifyPath(char[][] maze, int x, int y) {

        // To avoid ArrayOutOfBoundException by checking boundaries.
        if (x < 0 || y < 0 || x >= maze.length || y >= maze[x].length) return false;

        if (maze[x][y] == '#' || maze[x][y] == '.') {
            return false;
        }

        if (maze[x][y] == 'E') {
            return true;
        }
        // the start of the maze
        if (maze[x][y] == 'S') {
        } else {
            maze[x][y] = '.';
        }

        // check adjoining cells
        if (identifyPath(maze, x, y + 1)) {
            return true;
        } else if (identifyPath(maze, x - 1, y)) {
            return true;
        } else if (identifyPath(maze, x, y - 1)) {
            return true;
        } else if (identifyPath(maze, x + 1, y)) {
            return true;
        }

        if (maze[x][y] != 'S')
            maze[x][y] = ' ';
        return false;
    }

    private char[][] parseFileToCharArray(String fileName) {
        ArrayList<char[]> rows = new ArrayList<>();
        try {
//            try (BufferedReader br = new BufferedReader(new FileReader(fileName, "UTF-8"))) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"))) {
                String row = null;
                do {
                    row = br.readLine();
                    if (row != null) rows.add(row.toCharArray());
                } while (row != null);
            }
        } catch (IOException ex) {
            throw new MazeBusinessException(ex);
        }

        // Generate char[][] from rows read.
        char[][] inputArray = new char[rows.size()][];
        for (int rowNum = 0; rowNum < rows.size(); rowNum++) {
            inputArray[rowNum] = rows.get(rowNum);
        }
        return inputArray;
    }

    private static CommandLine parseInputParameters(String[] args) {
        // create Options object
        Options options = new Options();
        // add f option
        options.addOption("file", true, "input file name");

        HelpFormatter formatter = new HelpFormatter();
        formatter.printHelp( "file", options );

        CommandLineParser parser = new DefaultParser();
        CommandLine cmd = null;
        try {
            cmd = parser.parse( options, args);
        } catch (ParseException e) {
            throw new MazeBusinessException("Cannot proceed as input parameters not read. Please contact support/dev team@someaddress", e);
        }
        return cmd;
    }
}
