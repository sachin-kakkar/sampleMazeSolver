package com.sample.validator.content;

import com.sample.exception.MazeBusinessException;

/**
 * Checks number of starting and End points
 */
public class StartingAndEndPointAndInvalidCharValidator implements ContentValidator {
    @Override
    public boolean check(char[][] content) {
        int startingPoints = 0;
        int endPoints = 0;
        int invalidChar = 0;

        for (int row = 0; row < content.length ; row++) {
            for (int col = 0; col < content[row].length; col++) {
                char data = content[row][col];
                if (data == 'S') {startingPoints++;}
                else if (data == 'E') {endPoints++;}
                else if ((data != '#')  && (data != ' ')) {
                    invalidChar++;}
            }
        }
        if (startingPoints != 1 || endPoints != 1 || invalidChar > 0) {
            throw new MazeBusinessException("Content not in expected form. Expected only one S and one E or # and spaces in file.");
        }

        return true;
    }
}
