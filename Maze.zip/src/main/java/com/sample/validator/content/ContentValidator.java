package com.sample.validator.content;

public interface ContentValidator {
    public boolean check(char[][] content);
}
