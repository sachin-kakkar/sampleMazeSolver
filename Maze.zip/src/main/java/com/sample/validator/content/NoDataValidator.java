package com.sample.validator.content;


import com.sample.exception.MazeBusinessException;

public class NoDataValidator implements ContentValidator {
    @Override
    public boolean check(char[][] content) {
        if ((content == null) || (content.length == 0)) throw new MazeBusinessException("Empty data file. Input File contains no rows");
        return true;
    }
}
