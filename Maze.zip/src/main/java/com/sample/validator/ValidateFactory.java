package com.sample.validator;

import com.sample.validator.content.ContentValidator;
import com.sample.validator.content.NoDataValidator;
import com.sample.validator.content.StartingAndEndPointAndInvalidCharValidator;
import com.sample.validator.file.FileExistenceValidator;
import com.sample.validator.file.FileNameValidator;
import com.sample.validator.file.FileValidator;
import com.sample.validator.file.MimeTypeValidator;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Provides validation rules in order of execution. Allows reuse if needed and easy to add new files.
 */
public class ValidateFactory {
    public static Collection<FileValidator> getFileValidators() {
        Collection<FileValidator> validators = new ArrayList<>();
        validators.add(new FileNameValidator());
        validators.add(new FileExistenceValidator());
        validators.add(new MimeTypeValidator());
        return validators;
    }

    public static Collection<ContentValidator> getContentValidators() {
        Collection<ContentValidator> validators = new ArrayList<>();
        validators.add(new NoDataValidator());
        validators.add(new StartingAndEndPointAndInvalidCharValidator());
        return validators;
    }
}
