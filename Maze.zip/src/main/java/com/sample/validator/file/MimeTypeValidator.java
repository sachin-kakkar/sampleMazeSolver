package com.sample.validator.file;

import com.sample.exception.MazeBusinessException;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

/**
 * Checks mime type to ensure file is a text file.
 */
public class MimeTypeValidator implements FileValidator {
    public boolean check(String fileName) {

        File f = new File(fileName);

        try {
            String mime = Files.probeContentType(f.toPath());
            if (!"text/plain".equals(mime)) {throw new MazeBusinessException("File '"+ fileName + "' specified should be txt file.");};

        } catch (IOException e) {
            throw new MazeBusinessException("File "+ fileName + "specified should be txt file.");
        }

        return true;
    }
}
