package com.sample.validator.file;

public interface FileValidator {
    public boolean check(String fileNames);
}
