package com.sample.validator.file;

import com.sample.exception.MazeBusinessException;

import java.io.File;

/**
 * Check file exists on file system and is not directory.
 */
public class FileExistenceValidator implements FileValidator {
    public boolean check(String fileName) {

        File f = new File(fileName);
        if (!f.exists() || f.isDirectory()) {
            throw new MazeBusinessException("Input file '" + fileName + "' does not exists or is a directory. Please provide a valid .txt file.");
        }
        return true;
    }
}
