package com.sample.validator.file;

import com.sample.exception.MazeBusinessException;

/**
 * Check file name is not blank or empty string.
 */
public class FileNameValidator  implements FileValidator {
    public boolean check(String fileName) {

        // Validate in parameter
        if ((fileName == null) || (fileName.trim().equals("")))
            throw new MazeBusinessException("File name cannot be blank. Please provide filename with absolute path");

        return true;
    }

}
