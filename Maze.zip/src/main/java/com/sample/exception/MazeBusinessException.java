package com.sample.exception;

/**
 * Represent any Functional exception.
 * Also used to encapsulate details of any checked exception. It can be wrapped and thrown
 * again.
 * Default constructor is omitted to ensure a description of error is provided.
 *
 */
public class MazeBusinessException extends RuntimeException {

    public MazeBusinessException(String message) {
        super(message);
    }

    public MazeBusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public MazeBusinessException(Throwable cause) {
        super(cause);
    }

    public MazeBusinessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
